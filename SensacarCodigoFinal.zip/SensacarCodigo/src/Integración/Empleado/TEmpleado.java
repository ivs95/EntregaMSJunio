package Integración.Empleado;

public abstract class TEmpleado {

	private Boolean activo;

	private String DNI;

	private String nombre;

	private Integer id;

	private Integer idDepartamento;

	public TEmpleado(Boolean activo, String DNI, String nombre, Integer id, Integer departamento) {
		setActivo(activo);
		setDNI(DNI);
		setNombre(nombre);
		setID(id);
		setDepartamento(departamento);
	}

	public Boolean getActivo() {
		return this.activo;
	}

	public String getDNI() {
		return this.DNI;
	}

	public String getNombre() {
		return this.nombre;
	}

	public Integer getID() {
		return this.id;
	}

	public Integer getDepartamento() {
		return this.idDepartamento;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public void setDNI(String DNI) {
		this.DNI = DNI;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setID(Integer ID) {
		this.id = ID;
	}

	public void setDepartamento(Integer departamento) {
		this.idDepartamento = departamento;
	}
}