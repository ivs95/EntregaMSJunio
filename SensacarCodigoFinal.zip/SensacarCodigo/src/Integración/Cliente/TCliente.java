
package Integración.Cliente;


public class TCliente {

	private Integer telefono;

	private String nombre;
	
	private Integer id;

	private String DNI;
	
	private Boolean activo;

	public TCliente(Integer id,String DNI, String nombre, Integer telefono,  Boolean activo) {
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.DNI = DNI;
		this.activo= activo;
	}

	public Integer getTelefono() {
		return telefono;
	}

	public void setTelefono(Integer telefono) {
		this.telefono = telefono;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	
	
}