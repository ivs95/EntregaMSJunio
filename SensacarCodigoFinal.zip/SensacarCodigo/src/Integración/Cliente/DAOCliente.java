
package Integración.Cliente;

import java.util.ArrayList;

public interface DAOCliente {

	public Integer create(TCliente cliente);

	public Integer delete(Integer idCliente);

	public TCliente read(Integer idCliente);

	public ArrayList<TCliente> readAll();

	public Integer update(TCliente cliente);

	public TCliente readByDNI(String DNI);
}