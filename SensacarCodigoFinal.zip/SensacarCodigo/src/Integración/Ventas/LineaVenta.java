
package Integración.Ventas;

public class LineaVenta {

	private int cantidad;

	private Integer idArticulo;

	private float precioTotal;

	public LineaVenta(int idArticulo, int cantidad, float precioTotal) {
		this.idArticulo = idArticulo;
		this.cantidad = cantidad;
		this.precioTotal = precioTotal;
	}

	public int getCantidad() {
		return cantidad;
	}

	public Integer getIdArticulo() {
		return idArticulo;
	}

	public float getPrecioTotal() {
		return precioTotal;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public void setIdArticulo(int idArticulo) {
		this.idArticulo = idArticulo;
	}



	public void setPrecioTotal(float precioTotal) {
		this.precioTotal = precioTotal;
	}

}