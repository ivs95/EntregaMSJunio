
package Integración.Query;


public interface Query {

	public Object execute(Object param);
}