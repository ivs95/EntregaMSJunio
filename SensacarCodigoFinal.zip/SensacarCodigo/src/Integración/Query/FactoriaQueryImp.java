
package Integración.Query;

public class FactoriaQueryImp extends FactoriaQuery {

	public QueryCliente createQueryCliente() {
		return new QueryCliente();
	}

	public QueryModelo createQueryModelo() {

		return new QueryModelo();
	}
}