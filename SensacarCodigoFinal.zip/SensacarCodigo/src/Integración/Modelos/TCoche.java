
package Integración.Modelos;

public class TCoche extends TModelo {

	private Integer numeroPuertas;


	public TCoche(int id, float precio, boolean activo, int numPuertas, int stock, String nombre) {
		super(id, precio, activo, "coche", stock, nombre);
		this.numeroPuertas = numPuertas;
	}

	public void setNumPuertas(int numPuertas) {
		this.numeroPuertas = numPuertas;
	}

	public Integer getNumPuertas() {
		return numeroPuertas;
	}
}