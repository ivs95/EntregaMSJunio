
package Integración.Modelos;


public class TMoto extends TModelo {
	private int cilindrada;

	public TMoto(int id, float precio, boolean activo, int cilindrada, int stock, String nombre) {
		super(id, precio, activo, "moto", stock, nombre);
		this.cilindrada = cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}

	public Integer getCilindrada() {
		return cilindrada;
	}
}