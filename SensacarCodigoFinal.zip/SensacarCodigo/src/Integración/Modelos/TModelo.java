
package Integración.Modelos;

public class TModelo {
	private boolean activo;
	private float precio;
	private int ID;
	private String tipoVehiculo;
	private int stock;
	private String nombre;

	public TModelo(int id,float precio,boolean activo, String tipo, int stock, String nombre) {
		this.ID = id;
		this.precio = precio;
		this.activo = activo;
		this.tipoVehiculo = tipo;
		this.stock = stock;
		this.setNombre(nombre);
	}

	public boolean getActivo() {
		return this.activo;
	}

	public Integer getID() {
		return this.ID;
	}

	public String getNombre() {
		return this.nombre;
	}

	public float getPrecio() {
		return this.precio;
	}

	public Integer getStock() {
		return this.stock;
	}


	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public void setID(Integer ID) {
		this.ID = ID;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setPrecio(Integer precio) {
		this.precio = precio;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}
	public String getTipoVehiculo() {
		return tipoVehiculo;
	}

	public void setTipoVehiculo(String tipoVehiculo) {
		this.tipoVehiculo = tipoVehiculo;
	}

}