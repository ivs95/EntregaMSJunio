
package Negocio.Departamento;

import Integración.Departamento.TDepartamento;

public interface SADepartamento {

	public int crearDepartamento(TDepartamento departamento);

	public int borrarDepartamento(Integer idDepartamento);

	public int calcularNominaDeDepartamento(Integer idDepartamento);

	public TDepartamento leerDepartamento(int dato);
	
}