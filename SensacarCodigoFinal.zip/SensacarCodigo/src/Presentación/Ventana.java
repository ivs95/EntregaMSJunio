/**
 * 
 */
package Presentación;

import Presentación.Comandos.Contexto;


public interface Ventana {

	public void actualizar(Contexto contexto);

	void resetCamps();
}