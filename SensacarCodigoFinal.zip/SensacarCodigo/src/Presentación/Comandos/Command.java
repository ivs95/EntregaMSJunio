
package Presentación.Comandos;


public interface Command {

	public Contexto execute(Contexto contexto);
}